# SHA-256 Hashing
> for this hashing, we used sha-256

## Things need to have:
- banner, call from banner-sha.txt
- Allow single and multiple file for hashing with auto completion for every files using tab prompt_toolkit 
- allow for path travel `../../` or root dir `/`
- clear terminal when enter a new option except the banner

---

```
1. show banner
2. show option: 1- Hashing, q- Exit
3. case option 1:
	show "Enter file path:"
    print filename: hash

4. case option q:
    end
```